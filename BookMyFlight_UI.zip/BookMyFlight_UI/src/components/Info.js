import React, { Component } from "react";

class Info extends Component {
  render() {
    return (
      <div>
        <table className="table ">
          <thead>
            <tr>
              <th>Name</th>
              <th>Mobile Number</th>
              <th>Email</th>
              <th>GitHubLink</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Chetan Balwant Nagmoti</td>
              <td>8390569860</td>
              <td>chetanbnagmoti@gmail.com</td>
              <td>
                <a href="https://github.com/chetanbnagmoti">https://github.com/chetanbnagmoti</a>
              </td>
             
            </tr>
            <tr>
              <td>Chetan Balwant Nagmoti</td>
              <td>8390569860</td>
              <td>chetanbnagmoti@gmail.com</td>
              <td>
                <a href="https://github.com/chetanbnagmoti">https://github.com/chetanbnagmoti</a>
              </td>
             
            </tr>
            <tr>
              <td>Chetan Balwant Nagmoti</td>
              <td>8390569860</td>
              <td>chetanbnagmoti@gmail.com</td>
              <td>
                <a href="https://github.com/chetanbnagmoti">https://github.com/chetanbnagmoti</a>
              </td>
             
            </tr>
            <tr>
              <td>Chetan Balwant Nagmoti</td>
              <td>8390569860</td>
              <td>chetanbnagmoti@gmail.com</td>
              <td>
                <a href="https://github.com/chetanbnagmoti">https://github.com/chetanbnagmoti</a>
              </td>
             
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

export default Info;
